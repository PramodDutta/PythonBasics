# Dynamic Type Langauge - Python
# age ?
age = 45
# Declare a Variable
# Varaible name =  Variable Value / Literal
print(age) 
age = 90
print(age)

# # What is my age after 2 years
# age = age +2
# print(age) # 92

# What is my age before 2 years
age = age - 2
print(age)
