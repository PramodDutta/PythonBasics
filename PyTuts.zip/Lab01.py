print("Hello World")
print("Prmaod")
# > 3.8, 3.9, 3.10, 3.11 (Stable),  3.13 (Beta)
# 3.11 -> few new commands 90%