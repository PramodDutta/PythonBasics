age = 31 #int - Whole 1,2,3,4,4, -1, 32,4, --344, 
print(type(age))

# This is not possible in case of Java, Strong Types Lang.
# Python allows the change in the data type at runtime / in program also
age = 18.97 #float point 12.45, Decimal Number 0.34 , -13.4
print(type(age))

age = "Pramod" #string - "" , Char - P, r, A m, o , d
print(type(age))

# Boolean - bool - True, False
# Is Earth is Flat ? False
age = True
isMale  = False


isEarthIsFlat = True
print(type(age))


