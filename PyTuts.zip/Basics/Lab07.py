print("HelloWorld","Pramod","Ji","The Testing", 32, 34.45, True, sep="?")
print("HelloWorld","Pramod","Ji","The Testing", 32, 34.45, True, sep="  ")
print("HelloWorld","Pramod","Ji","The Testing", 32, 34.45, True)
# String - str
# Integer - int
# Float - float
# Boolean - bool