# This is Single Comment
'''

                        Multiple Comment / Doc String
                        Purpose of Comment ?  - Details about the Code or Instructions

'''