# Python Case Sentive 
# True  , true

#Indentation in Python
print("Hello World")
print("Pramod")